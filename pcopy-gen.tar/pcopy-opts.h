#ifndef AUTOOPTS_PCOPY_OPTS_H_GUARD
#define AUTOOPTS_PCOPY_OPTS_H_GUARD 1
#include "pcopy-cfg.h"
#include <autoopts/options.h>
#include <stdarg.h>

/*
 *  Ensure that the library used for compiling this generated header is at
 *  least as new as the version current when the header template was released
 *  (not counting patch version increments).  Also ensure that the oldest
 *  tolerable version is at least as old as what was current when the header
 *  template was released.
 */

/*
 *  Enumeration of each option:
 */
typedef enum {
    INDEX_OPT_THREAD_CT    =  1,
    INDEX_OPT_FLOW_RATE    =  2,
    INDEX_OPT_MAX_CHUNK    =  3,
    INDEX_OPT_DESTINATION  =  5,
    INDEX_OPT_QUIET        =  7,
    INDEX_OPT_VERSION      =  8,
    INDEX_OPT_HELP         =  9,
    INDEX_OPT_MORE_HELP    = 10,
    INDEX_OPT_USAGE        = 11,
    INDEX_OPT_SAVE_OPTS    = 12,
    INDEX_OPT_LOAD_OPTS    = 13
} teOptIndex;

#define OPTION_CT    14
#define PCOPY_VERSION       "0.4"
#define PCOPY_FULL_VERSION  "pcopy 0.4"

/*
 *  Interface defines for all options.  Replace "n" with the UPPER_CASED
 *  option name (as in the teOptIndex enumeration above).
 *  e.g. HAVE_OPT(LIMITS)
 */
#define         DESC(n) (pcopyOptions.pOptDesc[INDEX_OPT_## n])
#define     HAVE_OPT(n) (! UNUSED_OPT(& DESC(n)))
#define      OPT_ARG(n) (DESC(n).optArg.argString)
#define    STATE_OPT(n) (DESC(n).fOptState & OPTST_SET_MASK)
#define    COUNT_OPT(n) (DESC(n).optOccCt)
#define    ISSEL_OPT(n) (SELECTED_OPT(&DESC(n)))
#define ISUNUSED_OPT(n) (UNUSED_OPT(& DESC(n)))
#define  ENABLED_OPT(n) (! DISABLED_OPT(& DESC(n)))
#define  STACKCT_OPT(n) (((tArgList*)(DESC(n).optCookie))->useCt)
#define STACKLST_OPT(n) (((tArgList*)(DESC(n).optCookie))->apzArgs)
#define    CLEAR_OPT(n) STMTS( \
                DESC(n).fOptState &= OPTST_PERSISTENT_MASK;   \
                if ((DESC(n).fOptState & OPTST_INITENABLED) == 0) \
                    DESC(n).fOptState |= OPTST_DISABLED; \
                DESC(n).optCookie = NULL )

/* * * * * *
 *
 *  Enumeration of pcopy exit codes
 */
typedef enum {
    PCOPY_EXIT_SUCCESS = 0,
    PCOPY_EXIT_FAILURE = 1,
    PCOPY_EXIT_NO_MEM = 2,
    PCOPY_EXIT_FS_ERR_IN = 3,
    PCOPY_EXIT_FS_ERR_OUT = 4,
    PCOPY_EXIT_BAD_CONFIG = 5,
    PCOPY_EXIT_NO_CONFIG_INPUT = 66,
    PCOPY_EXIT_LIBOPTS_FAILURE = 70
} pcopy_exit_code_t;
/* * * * * *
 *
 *  Interface defines for specific options.
 */
#define VALUE_OPT_THREAD_CT      't'

#define OPT_VALUE_THREAD_CT      (DESC(THREAD_CT).optArg.argInt)
#define VALUE_OPT_FLOW_RATE      'f'

#define OPT_VALUE_FLOW_RATE      (DESC(FLOW_RATE).optArg.argInt)
#define VALUE_OPT_MAX_CHUNK      'c'

#define OPT_VALUE_MAX_CHUNK      (DESC(MAX_CHUNK).optArg.argInt)
#define SET_OPT_MAX_CHUNK(a)   STMTS( \
        DESC(MAX_CHUNK).optActualIndex = 3; \
        DESC(MAX_CHUNK).optActualValue = VALUE_OPT_MAX_CHUNK; \
        DESC(MAX_CHUNK).fOptState &= OPTST_PERSISTENT_MASK; \
        DESC(MAX_CHUNK).fOptState |= OPTST_SET; \
        DESC(MAX_CHUNK).optArg.argInt = (a); \
        (*(DESC(MAX_CHUNK).pOptProc))(&pcopyOptions, \
                pcopyOptions.pOptDesc + 3); )
#define VALUE_OPT_DESTINATION    'd'
#define VALUE_OPT_QUIET          'q'
#define VALUE_OPT_HELP          '?'
#define VALUE_OPT_MORE_HELP     '!'
#define VALUE_OPT_VERSION       'v'
#define VALUE_OPT_USAGE         'u'
#define VALUE_OPT_SAVE_OPTS     '>'
#define VALUE_OPT_LOAD_OPTS     '<'
#define SET_OPT_SAVE_OPTS(a)   STMTS( \
        DESC(SAVE_OPTS).fOptState &= OPTST_PERSISTENT_MASK; \
        DESC(SAVE_OPTS).fOptState |= OPTST_SET; \
        DESC(SAVE_OPTS).optArg.argString = (char const*)(a) )
/*
 *  Interface defines not associated with particular options
 */
#define ERRSKIP_OPTERR  STMTS(pcopyOptions.fOptSet &= ~OPTPROC_ERRSTOP)
#define ERRSTOP_OPTERR  STMTS(pcopyOptions.fOptSet |= OPTPROC_ERRSTOP)
#define RESTART_OPT(n)  STMTS( \
                pcopyOptions.curOptIdx = (n); \
                pcopyOptions.pzCurOpt  = NULL)
#define START_OPT       RESTART_OPT(1)
#define USAGE(c)        (*pcopyOptions.pUsageProc)(&pcopyOptions, c)
/* extracted from opthead.tlib near line 484 */

#ifdef  __cplusplus
extern "C" {
#endif
/*
 *  global exported definitions
 */
/*! @var List of pthreads doing the copies. */
extern pthread_t  *    pth_list;

/*! @var for accessing curses functions. */
extern pthread_mutex_t tty_mutex;

/*! @var Thread start is done condition variable.
 * The main thread must wait for each thread to open the input
 * and output files before starting the next thread.
 * Bad things happen if you do not wait.
 */
extern pthread_cond_t  th_start_cond;

/*! @var Condition variable accessor mutex. */
extern pthread_mutex_t th_start_mutex;

/*! @var Whether initscr() has been called.
 *  It is set false after a call to endwin(). */
extern bool            curses_active;

/*! @var minimum amount of time to consume per chunk.
 * If the flow-rate option has been specified, then this value is
 * computed based on that rate, the number of threads and the chunk
 * size.  The read thread sleeps if it finishes early.
 */
extern uint64_t        nsec_per_iteration;

/*! @var The size of the read for each iteration.
 * It is forced to be a multiple of the optimal size for a read.
 * That value is obtained from a stat() call.  The default value
 * is 16K (0x4000) bytes.
 */
extern unsigned long   iteration_chunk;

extern void vusage_message(char const * fmt, va_list ap);
extern void usage_message(char const * fmt, ...);


/* * * * * *
 *
 *  Declare the pcopy option descriptor.
 */
extern tOptions pcopyOptions;
# define OPT_NO_XLAT_CFG_NAMES
# define OPT_NO_XLAT_OPT_NAMES

# define OPT_XLAT_CFG_NAMES
# define OPT_XLAT_OPT_NAMES

# ifndef _
#   define _(_s)  _s
# endif

extern void vdie( int exit_code, char const * fmt, va_list);
extern void die(  int exit_code, char const * fmt, ...);
extern void fserr(int exit_code, char const * op, char const * fname);

#ifdef  __cplusplus
}
#endif
#endif /* AUTOOPTS_PCOPY_OPTS_H_GUARD */
/* pcopy-opts.h ends here */
